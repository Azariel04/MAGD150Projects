let x = 0;
let y = 400.0;
let wall = 300
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  print("Water is wet");
  print(9+10);
  ellipse(x,10,10,10);
  ellipse(10,y,10,10);
  y = y - 0.25 * y ;
  frameRate(10);
  x++;
  ellipse(mouseX,mouseY,50,50);
  let con = constrain(mouseX, width - 300, wall);
  ellipse(con,200,50,50);
  let boo = dist(width-400,width, height-400,height);
  ellipse(boo,boo, 300,200)
  let oooo = map(mouseX,100,300,100,300, true);
  ellipse(oooo,200,20,20);
  if(100>10);
    ellipse(300,300,10,10);
}