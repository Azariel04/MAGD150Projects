function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  //Main building
  rectMode(CORNER);
  strokeWeight(4);
  stroke(40);
  fill(75);
  rect(50,25,300,400);
  
  //1st(top) row windows
  rectMode(CORNER);
  fill(175);
  rect(80,50,50,45);
  rect(175,50,50,45);
  rect(270,50,50,45);
  
  //2nd row windows
  rectMode(CORNER);
  rect(80,125,50,45);
  rect(175,125,50,45);
  rect(270,125,50,45);
  
  //3rd row windows
  rectMode(CORNER);
  rect(80,200,50,45);
  rect(175,200,50,45);
  rect(270,200,50,45);
  
  //4th(bottom) row windows
  rectMode(CORNER);
  rect(80,275,50,45);
  rect(175,275,50,45);
  rect(270,275,50,45);
  
  //Doors
  rectMode(CENTER);
  rect(187.5,375,25,50);
  rect(212.5,375,25,50);
  
  //Roof
  rectMode(CORNER);
  rect(45,20,310,20);
  
  //Main floor windows
  rectMode(CORNER);
  rect(75,350,75,35);
  rect(250,350,75,35);
  
  //Left oval tree
  rectMode(CORNER);
  stroke(40);
  fill(50);
  rect(25,375,25,25);
  line(37.5,375,37.5,365);
  noStroke();
  fill(100);
  ellipse(37.5,345,15,40);
  
  //Right oval tree
  rectMode(CORNER);
  stroke(40);
  fill(50);
  rect(350,375,25,25);
  line(362.5,375,362.5,365);
  noStroke();
  fill(100);
  ellipse(362.5,345,15,40);
  
  //Left circle tree
  rectMode(CORNER);
  stroke(40);
  strokeWeight(4);
  fill(50);
  rect(0,375,25,25);
  line(12.5,375,12.5,365);
  stroke(100);
  fill(100);
  strokeWeight(25);
  point(12.5,355);
  
  //Right circle tree
  rectMode(CORNER);
  stroke(40);
  strokeWeight(4);
  fill(50);
  rect(375,375,25,25);
  line(387.5,375,387.5,365);
  stroke(100);
  fill(100);
  strokeWeight(25);
  point(387.5,355);
}