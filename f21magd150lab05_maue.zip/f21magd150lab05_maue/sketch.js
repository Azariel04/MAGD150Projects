let leftScreen = 80
let rightScreen = 420
let topScreen = 130
let bottomScreen = 370
let circleSize = 60
let circleX = 225
let circleY = 475
let rectSize = 60
let rectX = 255
let rectY = 460
var rectOver = false;
var circleOver = false;

function setup() {
  createCanvas(500, 500);
  baseColor = color(102);
  currentColor = baseColor;
  let circleColor = color(0);
  let rectColor = color(255);
  let circleSize = 60
  let circleX = 225
  let circleY = 475
  let rectSize = 60
  let rectX = 255
  let rectY = 460
  var rectOver = false;
  var circleOver = false;

}

function draw() {
  background(220);
  
  let xc = constrain(mouseX, leftScreen, rightScreen);
  let yc = constrain(mouseY, topScreen, bottomScreen);
  
  fill(0,0,0);
  rect(400,400,10,20);
  rect(100,400,10,20);
  rect(50,100,400,300);
  rect(200,450,100,50);
  fill(currentColor);
  rect(55,105,390,290);
  fill(255,0,0);
  ellipse(225,475,30,30);
  fill(0,255,0);
  rect(255,460,30,30);
  
  fill(0,255,255);
  ellipse(xc,yc,50,50);
}

function update( x,  y) {
  if ( overCircle(circleX, circleY, circleSize) ) {
    circleOver = true;
    rectOver = false;
  } else if ( overRect(rectX, rectY, rectSize, rectSize) ) {
    rectOver = true;
    circleOver = false;
  } else {
    circleOver = rectOver = false;
  }
}

function mousePressed() {
  if (circleOver) {
    currentColor = circleColor;
  }
  if (rectOver) {
    currentColor = rectColor;
  }
}