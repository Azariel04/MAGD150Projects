let leaves = []; //Creates an array for the water droplets

function setup() {
  createCanvas(700, 400);
  for (let i = 0; i < 150; i++) {
    leaves.push(new Leaf());
  }
}

function draw() {
  background(50,89,100);
  for (let i =0; i < leaves.length; i++) {
    leaves[i].move();
    leaves[i].display();
  }
}

class Leaf {
  //sets the values that water droplets will be generated with
  constructor() {
    this.x = random(width);
    this.y = random(height-800);
    this.diameter = random(10,30);
    this.diameter2 = random(20,40);
    this.speed = 0.5;
    this.c = color(0,random(255),255);
  }
  //sets how the water droplets will fall down the screen
  move() {
    this.y = this.y + this.speed
  }
  //draws the water droplets in varying shades of blue
  display() {
    fill(this.c);
    ellipse(this.x,this.y,this.diameter,this.diameter2);
  }
}