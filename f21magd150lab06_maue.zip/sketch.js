var mx = 275
var speed = 1

//Draws the player controlled ship
function ship(x,y,l){
  fill(255,0,0);
  rect(mouseX,y-l,l,l);
  rect(mouseX+l,y,l,l);
  rect(mouseX-l,y,l,l);
  fill(0,255,255);
  rect(mouseX,y,l,l);
}

//moves the invaders
function move(){
  if(mx>550){
    speed = -1;
  }else if(mx<25){
    speed = 1;
  }
  mx = mx + speed;
}

//draws the invaders
function invader(y,l){
  fill(255,0,255);
  rect(mx,y,l);
  fill(0,255,0);
  rect(mx,y+l,l);
  rect(mx+l,y,l);
  rect(mx-l,y,l);
}

//Draws the rotated invader
function invaderRotate(y,l){
  rotate(90);
  fill(255,0,255);
  rect(mx,y,l);
  fill(0,255,0);
  rect(mx,y+l,l);
  rect(mx+l,y,l);
  rect(mx-l,y,l);
}

//Draws the translated invader
function invaderTranslate(y,l){
  rotate(270);
  translate(0,75);
  fill(255,0,255);
  rect(mx,y,l);
  fill(0,255,0);
  rect(mx,y+l,l);
  rect(mx+l,y,l);
  rect(mx-l,y,l);
}

//Draws the scaled invader
function invaderScale(y,l){
  translate(0,-175);
  scale(1.5);
  fill(255,0,255);
  rect(mx,y,l);
  fill(0,255,0);
  rect(mx,y+l,l);
  rect(mx+l,y,l);
  rect(mx-l,y,l);
}

function setup() {
  createCanvas(600, 600);
  angleMode(DEGREES);
}

function draw() {
  background(220);
  ship(275,500,25);
  invader(100,25);
  invaderRotate(-100,25);
  invaderTranslate(100,25);
  invaderScale(100,25);
  move();
}